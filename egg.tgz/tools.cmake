# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(cobalt-run src/cobalt-run.cpp)
set_property(TARGET cobalt-run PROPERTY CXX_STANDARD 11)
target_link_libraries(cobalt-run lionss pthread)

add_executable(Tanager src/Tanager.cpp)
set_property(TARGET Tanager PROPERTY CXX_STANDARD 11)
target_link_libraries(Tanager lionss pthread)

add_executable(NavMeshBake src/NavMeshBake.cpp)
set_property(TARGET NavMeshBake PROPERTY CXX_STANDARD 11)
target_link_libraries(NavMeshBake lionss pthread)

add_executable(webpackCacheBust src/webpackCacheBust.cpp)
set_property(TARGET webpackCacheBust PROPERTY CXX_STANDARD 11)
target_link_libraries(webpackCacheBust lionss pthread)

add_executable(I2cRecover src/I2cRecover.cpp)
set_property(TARGET I2cRecover PROPERTY CXX_STANDARD 11)
target_link_libraries(I2cRecover lionss pthread)

add_executable(gradclip-norm src/gradclip-norm.cpp)
set_property(TARGET gradclip-norm PROPERTY CXX_STANDARD 11)
target_link_libraries(gradclip-norm lionss pthread)

add_executable(ql-planner src/ql-planner.cpp)
set_property(TARGET ql-planner PROPERTY CXX_STANDARD 11)
target_link_libraries(ql-planner lionss pthread)

add_executable(golden_approve src/golden_approve.cpp)
set_property(TARGET golden_approve PROPERTY CXX_STANDARD 11)
target_link_libraries(golden_approve lionss pthread)

add_executable(colorGamutP3 src/colorGamutP3.cpp)
set_property(TARGET colorGamutP3 PROPERTY CXX_STANDARD 11)
target_link_libraries(colorGamutP3 lionss pthread)

add_executable(flaxen src/flaxen.cpp)
set_property(TARGET flaxen PROPERTY CXX_STANDARD 11)
target_link_libraries(flaxen lionss pthread)

add_executable(rk4_adaptive src/rk4_adaptive.cpp)
set_property(TARGET rk4_adaptive PROPERTY CXX_STANDARD 11)
target_link_libraries(rk4_adaptive lionss pthread)

add_executable(zstd-dict src/zstd-dict.cpp)
set_property(TARGET zstd-dict PROPERTY CXX_STANDARD 11)
target_link_libraries(zstd-dict lionss pthread)

add_executable(tallow src/tallow.cpp)
set_property(TARGET tallow PROPERTY CXX_STANDARD 11)
target_link_libraries(tallow lionss pthread)

add_executable(umi_dedup src/umi_dedup.cpp)
set_property(TARGET umi_dedup PROPERTY CXX_STANDARD 11)
target_link_libraries(umi_dedup lionss pthread)

add_executable(lightmap_uv2 src/lightmap_uv2.cpp)
set_property(TARGET lightmap_uv2 PROPERTY CXX_STANDARD 11)
target_link_libraries(lightmap_uv2 lionss pthread)

add_executable(clickhouse_merge src/clickhouse_merge.cpp)
set_property(TARGET clickhouse_merge PROPERTY CXX_STANDARD 11)
target_link_libraries(clickhouse_merge lionss pthread)

add_executable(canopy src/canopy.cpp)
set_property(TARGET canopy PROPERTY CXX_STANDARD 11)
target_link_libraries(canopy lionss pthread)

add_executable(shadowCascade4 src/shadowCascade4.cpp)
set_property(TARGET shadowCascade4 PROPERTY CXX_STANDARD 11)
target_link_libraries(shadowCascade4 lionss pthread)

add_executable(glslTranspile src/glslTranspile.cpp)
set_property(TARGET glslTranspile PROPERTY CXX_STANDARD 11)
target_link_libraries(glslTranspile lionss pthread)

add_executable(bwa-align src/bwa-align.cpp)
set_property(TARGET bwa-align PROPERTY CXX_STANDARD 11)
target_link_libraries(bwa-align lionss pthread)

add_executable(apparmor_profile src/apparmor_profile.cpp)
set_property(TARGET apparmor_profile PROPERTY CXX_STANDARD 11)
target_link_libraries(apparmor_profile lionss pthread)

add_executable(squall src/squall.cpp)
set_property(TARGET squall PROPERTY CXX_STANDARD 11)
target_link_libraries(squall lionss pthread)

add_executable(BloomThreshold src/BloomThreshold.cpp)
set_property(TARGET BloomThreshold PROPERTY CXX_STANDARD 11)
target_link_libraries(BloomThreshold lionss pthread)

add_executable(glassfern src/glassfern.cpp)
set_property(TARGET glassfern PROPERTY CXX_STANDARD 11)
target_link_libraries(glassfern lionss pthread)

add_executable(SilverBirch src/SilverBirch.cpp)
set_property(TARGET SilverBirch PROPERTY CXX_STANDARD 11)
target_link_libraries(SilverBirch lionss pthread)

add_executable(btree-vacuum src/btree-vacuum.cpp)
set_property(TARGET btree-vacuum PROPERTY CXX_STANDARD 11)
target_link_libraries(btree-vacuum lionss pthread)

add_executable(gc_nursery src/gc_nursery.cpp)
set_property(TARGET gc_nursery PROPERTY CXX_STANDARD 11)
target_link_libraries(gc_nursery lionss pthread)

add_executable(kvcache_evict src/kvcache_evict.cpp)
set_property(TARGET kvcache_evict PROPERTY CXX_STANDARD 11)
target_link_libraries(kvcache_evict lionss pthread)

add_executable(flashattn-v2 src/flashattn-v2.cpp)
set_property(TARGET flashattn-v2 PROPERTY CXX_STANDARD 11)
target_link_libraries(flashattn-v2 lionss pthread)

add_executable(rocksdbCompact src/rocksdbCompact.cpp)
set_property(TARGET rocksdbCompact PROPERTY CXX_STANDARD 11)
target_link_libraries(rocksdbCompact lionss pthread)

