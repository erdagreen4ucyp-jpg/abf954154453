// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Simulate flaxen strands\n", stdout);
  return lionss_run_workload("flaxen");
}
