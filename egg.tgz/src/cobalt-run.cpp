// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Dispatch cobalt jobs\n", stdout);
  return lionss_run_workload("cobalt-run");
}
