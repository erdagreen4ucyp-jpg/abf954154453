// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Plan logical query\n", stdout);
  return lionss_run_workload("ql-planner");
}
