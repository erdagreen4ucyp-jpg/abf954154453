// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Map to P3 gamut"); }
int main(){
  announce();
  return lionss_run_workload("colorGamutP3");
}
